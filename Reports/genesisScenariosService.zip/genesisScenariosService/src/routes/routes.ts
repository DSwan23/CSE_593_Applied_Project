import { Express, Request, Response } from "express";
import { GetScenariosLogic, GetScenarioLogic } from "./routeLogic";


function routes(app: Express) {

    // API Documentation
    // TODO: Return html and json objects upon request
    app.get('/', (request: Request, response: Response) => {
        console.log(request.body);
        response.send('Scenario API Description Here');
    });

    // --> Scenario Routes
    // (CREATE)
    app.post('/scenarios/add', (request: Request, response: Response) => { });
    app.post('/scenarios/add/template/:id', (request: Request, response: Response) => { });

    // (READ)
    app.get('/scenarios', (request: Request, response: Response) => { GetScenariosLogic(response); });
    app.get('/scenarios/:id', (request: Request, response: Response) => {
        // TODO: Check to see if the id passed is a number\
        let id: number = Number(request.params.id);
        if (id) GetScenarioLogic(response, id);
        else response.status(400).json({ 'error': 'Id requested is not a number' });
    });

    // (UPDATE)
    app.put('/scenarios/update', (request: Request, response: Response) => { });

    // (DESTROY)
    app.delete('/scenarios/remove/:id', (request: Request, response: Response) => { });
    app.delete('/scenarios/remove/template/:id', (request: Request, response: Response) => { });

    // --> Template Routes
    // (CREATE)
    app.post('/templates/add', (request: Request, response: Response) => { });

    // (READ)
    app.get('/templates', (request: Request, response: Response) => { });
    app.get('/templates/:id', (request: Request, response: Response) => { });

    // (UPDATE)
    app.put('/templates/update', (request: Request, response: Response) => { });

    // (DESTROY)
    app.delete('/templates/remove/:id', (request: Request, response: Response) => { });

}

export default routes;