import { Response } from "express";
import { GetScenarios, GetScenario } from "../database/mysqlDatabase";


// --> Scenario Route Logic
function GetScenariosLogic(response: Response) {
    // Attempt to get the scenario data from the database
    GetScenarios()
        .then(scenarioData => {
            // Check to see if anything was returned
            if (scenarioData.length == 0) response.status(204).json(scenarioData);
            else response.status(200).json(scenarioData);
        }
        )
        .catch(error => {
            // TODO: Log the message
            response.status(500);
        });
};

function GetScenarioLogic(response: Response, id: number) {
    // Attempt to get the scenario from the database
    GetScenario(id)
        .then(scenarioData => {
            // Check to see if anything was returned
            if (!scenarioData) response.status(204).json(scenarioData);
            else response.status(200).json(scenarioData);
        })
        .catch(error => {
            // TODO: Log the message
            response.status(500);
        });
}

export { GetScenariosLogic, GetScenarioLogic }